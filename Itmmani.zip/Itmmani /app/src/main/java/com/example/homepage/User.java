package com.example.homepage;

public class User {
    private int id;
    private String name, username, email, phone, emergencyContact, location, age, password;

    public User() {}

    public User(int id, String name, String username, String email, String phone, String emergencyContact, String location, String age, String password) {
        this.id = id;
        this.name = name;
        this.username = username;
        this.email = email;
        this.phone = phone;
        this.emergencyContact = emergencyContact;
        this.location = location;
        this.age = age;
        this.password = password;
    }

    public User(String name, String username, String email, String phone, String emergencyContact, String location, String age, String password) {
        this.name = name;
        this.username = username;
        this.email = email;
        this.phone = phone;
        this.emergencyContact = emergencyContact;
        this.location = location;
        this.age = age;
        this.password = password;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getUsername() {
        return username;
    }

    public String getEmail() {
        return email;
    }

    public String getPhone() {
        return phone;
    }

    public String getEmergencyContact() {
        return emergencyContact;
    }

    public String getLocation() {
        return location;
    }

    public String getAge() {
        return age;
    }

    public String getPassword() {
        return password;
    }
}

