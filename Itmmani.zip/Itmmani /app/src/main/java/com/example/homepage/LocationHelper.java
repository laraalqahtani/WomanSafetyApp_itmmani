package com.example.homepage;

import android.content.Context;
import android.location.Location;
import android.location.LocationManager;

public class LocationHelper {

    public static Location getLastKnownLocation(Context context) {
        LocationManager locationManager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);

        if (locationManager != null) {
            try {
                // Try to get the last known location using the network provider
                Location lastKnownLocation = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);

                // If network provider is not available, use the GPS provider
                if (lastKnownLocation == null) {
                    lastKnownLocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                }

                return lastKnownLocation;
            } catch (SecurityException e) {
                e.printStackTrace();
            }
        }

        return null;
    }
}
