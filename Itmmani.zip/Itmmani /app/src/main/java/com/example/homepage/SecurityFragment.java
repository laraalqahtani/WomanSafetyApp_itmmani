package com.example.homepage;

import android.content.Intent;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


public class SecurityFragment extends Fragment {


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v =  inflater.inflate(R.layout.fragment_security, container, false);
        CardView arrangePhone = v.findViewById(R.id.arrange);
        arrangePhone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phoneNumber = "tel:999";
                Intent dialIntent = new Intent(Intent.ACTION_DIAL);
                dialIntent.setData(Uri.parse(phoneNumber));
                startActivity(dialIntent);
            }
        });

        CardView showNearestPoliceStationsButton = v.findViewById(R.id.location);
        showNearestPoliceStationsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showNearestPoliceStations();
            }
        });
        return v ;
    }

    private void showNearestPoliceStations() {
        Location lastKnownLocation = LocationHelper.getLastKnownLocation(requireContext());
        double userLatitude = 37.7749;
        double userLongitude = -122.4194;
        if (lastKnownLocation != null) {
            userLatitude = lastKnownLocation.getLatitude();
            userLongitude = lastKnownLocation.getLongitude();
        }


        Uri gmmIntentUri = Uri.parse("geo:" + userLatitude + "," + userLongitude + "?q=police+station");

        Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
        mapIntent.setPackage("com.google.android.apps.maps");

        if (mapIntent.resolveActivity(requireContext().getPackageManager()) != null) {
            startActivity(mapIntent);
        } else {
            Uri webIntentUri = Uri.parse("https://www.google.com/maps/search/?api=1&query=police+station");
            Intent webIntent = new Intent(Intent.ACTION_VIEW, webIntentUri);
            startActivity(webIntent);
        }

    }
}