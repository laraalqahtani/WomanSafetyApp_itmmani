package com.example.homepage;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

public class SettingFragment extends Fragment {

    Button Update;
    Button Logout;
    Button Privacy;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_setting, container, false);

        Update = view.findViewById(R.id.UpdateButton);
        Intent update = new Intent(getActivity(), UpdateActivity.class);
        Update.setOnClickListener(v -> startActivity(update));

        Logout = view.findViewById(R.id.LogoutButton);
        Intent logout = new Intent(getActivity(), Login.class);
        Logout.setOnClickListener(v -> startActivity(logout));

        Privacy = view.findViewById(R.id.Privacy_Policy);
        Intent privacy = new Intent(getActivity(), PrivacyPolicyActivity.class);
        Privacy.setOnClickListener(v -> startActivity(privacy));

        return view;
    }

}
