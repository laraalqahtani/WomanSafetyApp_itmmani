package com.example.homepage;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {
    public static final String DBNAME="UserDB.db";
    public static final int DB_VERSION=1;

    public DBHelper(Context context){

        super(context,DBNAME,null,DB_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase MyDB) {
        MyDB.execSQL("create Table users(id INTEGER PRIMARY KEY,name TEXT,email TEXT,phone TEXT, emergency_contact TEXT,location TEXT,age TEXT, username TEXT, password TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase MyDB, int i, int i1) {
        MyDB.execSQL("drop table if exists users");
    }

    public boolean insertData (String name , String email,String phone,String emergency_contact,String location,String age , String username,String password){
        SQLiteDatabase MyDB=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put("name",name);
        contentValues.put("email",email);
        contentValues.put("phone",phone);
        contentValues.put("emergency_contact",emergency_contact);
        contentValues.put("location",location);
        contentValues.put("age",age);
        contentValues.put("username",username);
        contentValues.put("password",password);

        long result = MyDB.insert("users", null, contentValues);
        return result != -1;
    }
    public boolean checkUsername(String username){
        SQLiteDatabase MyDB=this.getWritableDatabase();
        Cursor cursor =MyDB.rawQuery("Select * from users where username = ?",new String[]{username});
        if (cursor.getCount()>0)
        { return true;}
        else
        {  return false;}

    }
    public boolean checkUsernamePassword(String username,String password) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from users where username = ? and password = ? ", new String[]{username, password});
        if (cursor.getCount() > 0) {
            return true;
        } else {
            return false;
        }
    }

    public boolean login(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query("users",
                new String[]{"id", "username", "password"},
                null, null, null, null, null, null);

        int userId = -1;

        if (cursor != null) {
            if (cursor.moveToFirst()) {
                do {
                    String _username = cursor.getString(1);
                    String _password = cursor.getString(2);

                    if (_username.equals(username) && _password.equals(password)) {
                        userId = cursor.getInt(0);
                        cursor.close();
                        break;
                    }
                } while (cursor.moveToNext());
            }
        }

        SignInInfo.signin(userId);
        db.close();
        return userId > 0;
    }

    public User getUser() {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(
                "users",
                new String[]{
                        "id", "name", "username", "email", "phone", "emergency_contact", "location", "age", "password"
                },
                null, null, null, null, null);

        User user = null;

        if (cursor != null) {
            if (cursor.moveToFirst()) {
                int id = cursor.getInt(0);

                if (id == SignInInfo.getUserId()) {
                    user = new User(
                            id,
                            cursor.getString(1),
                            cursor.getString(2),
                            cursor.getString(3),
                            cursor.getString(4),
                            cursor.getString(5),
                            cursor.getString(6),
                            cursor.getString(7),
                            cursor.getString(8)
                    );
                }
            }
        }

//        db.close();
        return user;
    }

    public boolean updateUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("name", user.getName());
        values.put("email", user.getEmail());
        values.put("phone", user.getPhone());
        values.put("emergency_contact", user.getEmergencyContact());
        values.put("location", user.getLocation());
        values.put("age", user.getAge());
        values.put("password", user.getPassword());

        String selection = "id" + "=?";
        String[] selectionArgs = { String.valueOf(SignInInfo.getUserId()) };

        // Update the note based on its ID
        int result = db.update("users", values, selection, selectionArgs);

        // Close the database connection
        db.close();
        return result > 0;
    }

    public boolean deleteUser() {
        SQLiteDatabase db = this.getWritableDatabase();

        String selection = "id" + "=?";
        String[] selectionArgs = { String.valueOf(SignInInfo.getUserId()) };

        // Delete the note based on its ID
        int result = db.delete("users", selection, selectionArgs);

        // Close the database connection
        db.close();
        return result > 0;
    }

    public boolean UpdateData (String name , String email,String phone,String emergency_contact,String location,String age , String username,String password) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("name", name);
        contentValues.put("email", email);
        contentValues.put("phone", phone);
        contentValues.put("emergency_contact", emergency_contact);
        contentValues.put("location", location);
        contentValues.put("age", age);
        contentValues.put("password", password);

        Cursor cursor = MyDB.rawQuery("Select * from users where username = ?", new String[]{username});
        if (cursor.getCount() > 0) {

            long result = MyDB.update("users", contentValues, "username=?", new String[]{username});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }


    }




}
