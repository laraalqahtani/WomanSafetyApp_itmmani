package com.example.homepage;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.provider.CalendarContract;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;


public class ConsellingFragment extends Fragment {



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_conselling, container, false);

        LinearLayout betterhelp = v.findViewById(R.id.better_header);
        betterhelp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String websiteUrl = "https://www.betterhelp.com/get-started/?utm_source=AdWords&utm_medium=Search_PPC_m&utm_term=betterhelp_e&utm_content=133525856150&network=g&placement=&target=&matchtype=e&utm_campaign=15228709182&ad_type=text&adposition=&kwd_id=kwd-300752210814&gbraid=0AAAAADqBHiZlwG-3P4CdiMfQo75DNkAVU&not_found=1&gor=start-go";
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(websiteUrl));
                startActivity(browserIntent);
            }
        });

        TextView email = v.findViewById(R.id.email);
        email.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String emailAddress = "contact@betterhelp.com";
                Intent emailIntent = new Intent(Intent.ACTION_SENDTO);
                emailIntent.setData(Uri.parse("mailto:" + emailAddress));
                startActivity(emailIntent);
            }
        });

        TextView betterPhone = v.findViewById(R.id.better_phon);
        betterPhone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phoneNumber = "tel:990";

                Intent dialIntent = new Intent(Intent.ACTION_DIAL);
                dialIntent.setData(Uri.parse(phoneNumber));

                startActivity(dialIntent);
            }
        });


        LinearLayout shezlong = v.findViewById(R.id.shezlong_hedader);
        shezlong.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String websiteUrl = "https://www.shezlong.com/en/";
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(websiteUrl));
                startActivity(browserIntent);
            }
        });

        TextView shezlongPhone = v.findViewById(R.id.shezlong_phone);
        shezlongPhone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phoneNumber = "tel:1800 806 292";

                Intent dialIntent = new Intent(Intent.ACTION_DIAL);
                dialIntent.setData(Uri.parse(phoneNumber));

                startActivity(dialIntent);
            }
        });

        CardView chatCard = v.findViewById(R.id.card_3);
        chatCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String websiteUrl = "https://www.my.gov.sa/wps/portal/snp/servicesDirectory/servicedetails/12423";
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(websiteUrl));

                startActivity(browserIntent);
            }
        });


        CardView appointmentCard = v.findViewById(R.id.card_4);
        appointmentCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create an Intent with ACTION_INSERT for the Calendar
                Intent calendarIntent = new Intent(Intent.ACTION_INSERT)
                        .setData(CalendarContract.Events.CONTENT_URI)
                        .putExtra(CalendarContract.Events.TITLE, "Appointment Title")
                        .putExtra(CalendarContract.Events.DESCRIPTION, "Appointment Description")
                        .putExtra(CalendarContract.Events.EVENT_LOCATION, "Appointment Location")
                        .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, System.currentTimeMillis())
                        .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, System.currentTimeMillis() + 3600000); // 1 hour in milliseconds

                // Start the calendar activity
                startActivity(calendarIntent);
            }
        });

        return v ;
    }
}