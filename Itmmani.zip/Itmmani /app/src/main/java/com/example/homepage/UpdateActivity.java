package com.example.homepage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.widget.Toolbar;

public class UpdateActivity extends AppCompatActivity {
    EditText name, email, phone, emergencyContact, location, age, username, password;
    Button  backToSettingsButton, updateButton; // Added 'updateButton'
    DBHelper DB;
    Toolbar toolbar;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_update);

        name = findViewById(R.id.editTextName);
        email = findViewById(R.id.editTextEmail);
        phone = findViewById(R.id.editTextPhone);
        emergencyContact = findViewById(R.id.editTextEmergencyContact);
        location = findViewById(R.id.editTextLocation);
        age = findViewById(R.id.editTextAge);
        username = findViewById(R.id.editTextUsername);
        password = findViewById(R.id.editTextPassword);
        backToSettingsButton = findViewById(R.id.Back_to_settings2);
        updateButton = findViewById(R.id.Update); // Added 'updateButton'
        DB = new DBHelper(this);
        toolbar = findViewById(R.id.toolbar);

        loadData();

        updateButton.setOnClickListener(v -> {
            updateData();
        });

        backToSettingsButton.setOnClickListener(v -> {
            finish();
        });
    }

    private void loadData() {
        User user = DB.getUser();
        if (user != null) {
            name.setText(user.getName());
            email.setText(user.getEmail());
            phone.setText(user.getPhone());
            emergencyContact.setText(user.getEmergencyContact());
            location.setText(user.getLocation());
            age.setText(user.getAge());
            username.setText(user.getUsername());
            password.setText(user.getPassword());
        }
    }

    private void updateData() {
        String Name = name.getText().toString();
        String Email = email.getText().toString();
        String Phone = phone.getText().toString();
        String EmergencyContact = emergencyContact.getText().toString();
        String Location = location.getText().toString();
        String Age = age.getText().toString();
        String Username = username.getText().toString();
        String Password = password.getText().toString();

        User user = new User(
                Name,
                Username,
                Email,
                Phone,
                EmergencyContact,
                Location,
                Age,
                Password
        );

        // UpdateActivity data
        boolean checkUpdateData = DB.updateUser(user);
        if (checkUpdateData) {
            Toast.makeText(UpdateActivity.this, "Updated!", Toast.LENGTH_SHORT).show();
            loadData();
        }
    }
}
