package com.example.homepage;



public class SignInInfo {
    private static int id = -1;

    public static void signin(int userId) {
        id = userId;
    }

    public static int getUserId() {
        return id;
    }

    public static void signout() {
        id = -1;
    }
}
