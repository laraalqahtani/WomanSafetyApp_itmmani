package com.example.homepage;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.app.DatePickerDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import java.util.Calendar;
import android.widget.DatePicker;

public class SignUp extends AppCompatActivity {
    EditText name,email,phone,emergencyContact,location,bd,username,password;
    Button SignUp;
    DBHelper DB;
    Toolbar toolbar;
    DatePickerDialog datePickerDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        name = (EditText) findViewById(R.id.editTextName);
        email = (EditText) findViewById(R.id.editTextEmail);
        phone = (EditText) findViewById(R.id.editTextPhone);
        emergencyContact = (EditText) findViewById(R.id.editTextEmergencyContact);
        location = (EditText) findViewById(R.id.editTextLocation);
        bd = (EditText) findViewById(R.id.editTextBirthday);
        username = (EditText) findViewById(R.id.editTextUsername); // Add this line
        password = (EditText) findViewById(R.id.editTextPassword);
        SignUp = (Button) findViewById(R.id.signUpButton);
        DB = new DBHelper(this);
        toolbar = findViewById(R.id.toolbar);

        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        datePickerDialog = new DatePickerDialog(
                SignUp.this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                        String selectedDate = (month + 1) + "/" + day + "/" + year;
                        // Set the selected date to the EditText
                        bd.setText(selectedDate);
                    }
                },
                year, month, day
        );


        SignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //get user data
                String Name = name.getText().toString();
                String Email = email.getText().toString();
                String Phone = phone.getText().toString();
                String EmergencyContact = emergencyContact.getText().toString();
                String Location = location.getText().toString();
                String Bd = bd.getText().toString();
                String Username = username.getText().toString();
                String Password = password.getText().toString();

                // Check user entered data
                if (Name.equals("") || Email.equals("") || Phone.equals("") || EmergencyContact.equals("") || Location.equals("") || Bd.equals("") || Username.equals("") || Password.equals("")) {
                    Toast.makeText(SignUp.this, "Please enter all required fields", Toast.LENGTH_SHORT).show();
                } else {
                    // Validate email format
                    if (!android.util.Patterns.EMAIL_ADDRESS.matcher(Email).matches()) {
                        Toast.makeText(SignUp.this, "Please enter a valid email address", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    // Validate password length
                    if (Password.length() < 8) {
                        Toast.makeText(SignUp.this, "Password must be at least 8 characters long", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    // Validate phone number length
                    if (Phone.length() != 10|| (!Phone.startsWith("05"))) {
                        Toast.makeText(SignUp.this, "Please enter a 10-digit phone number", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    // Validate Emergency Contact  length
                    if (EmergencyContact.length() != 10|| (!Phone.startsWith("05"))) {
                        Toast.makeText(SignUp.this, "Please enter a 10-digit Emergency Contact", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    Boolean checkUser = DB.checkUsername(Username);
                    if (checkUser == false) {
                        Boolean insert = DB.insertData(Name, Email, Phone, EmergencyContact, Location, Bd, Username, Password);
                        if (insert == true) {
                            Toast.makeText(SignUp.this, "Registered successfully!", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(getApplicationContext(), Login.class);
                            startActivity(intent);
                        } else {
                            Toast.makeText(SignUp.this, "Registration Failed", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(SignUp.this, "This username already exists..", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        bd.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    // Show date picker when the EditText gains focus
                    datePickerDialog.show();
                    bd.clearFocus(); // Clear focus to prevent the keyboard from appearing
                }
            }
        });



    }
}