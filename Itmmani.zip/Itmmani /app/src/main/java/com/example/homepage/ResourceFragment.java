package com.example.homepage;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

public class ResourceFragment extends Fragment {


    Button Concerning_behv;
    Button Staying_Safe;
    Button Health;
    Button Respect;
    Button Formal;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_resource, container, false);

        Concerning_behv = view.findViewById(R.id.Concerning_behaviors);
        Staying_Safe= view.findViewById(R.id.StayingSafe);
        Health = view.findViewById(R.id.Health_and_wellbeing);
        Respect = view.findViewById(R.id.Respect_and_inclusion);
        Formal =view.findViewById(R.id.Formal_Process);



        Concerning_behv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://www.mayoclinic.org/healthy-lifestyle/adult-health/in-depth/domestic-violence/art-20048397");
            }
        });


        Staying_Safe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://www.instructables.com/Basic-Street-Safety-for-Women/");
            }
        });

        Health.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://www.self.com/health");
            }
        });

        Respect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://dai-global-developments.com/articles/womens-inclusion-and-empowerment/");
            }
        });

        Formal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://www.jstor.org/stable/pdf/resrep02478.11.pdf");
            }
        });
        return view;
    }

    private void gotoUrl(String s) {

        Uri uri = Uri.parse(s);
        startActivity(new Intent(Intent.ACTION_VIEW, uri));
    }


}