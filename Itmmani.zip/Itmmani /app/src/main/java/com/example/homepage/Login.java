package com.example.homepage;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Login extends AppCompatActivity {
    EditText username, password;
    Button Login, SignUp;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        username = findViewById(R.id.usernameEditText);
        password = findViewById(R.id.passwordEditText);
        Login = findViewById(R.id.LoginButton);
        SignUp = findViewById(R.id.signUpButton);
        DB = new DBHelper(this);

        //Login
        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = username.getText().toString();
                String pass = password.getText().toString();
                if (user.equals("") || pass.equals("")) {
                    Toast.makeText(Login.this, "Please enter all required fields", Toast.LENGTH_SHORT).show();
                } else {
//                    Boolean checkUser = DB.checkUsernamePassword(user, pass);
                    boolean checkUser = DB.login(user, pass);
                    if (checkUser) {
                        Toast.makeText(Login.this, "Login successful!", Toast.LENGTH_SHORT).show();
                        loadHomeFragment(); // Load HomeFragment on successful login
                    } else {
                        Toast.makeText(Login.this, "invalid input! \ncheck username and password is correctly entered!", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        //signup
        SignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), SignUp.class);
                startActivity(intent);
            }
        });
    }

    // In LoginActivity
    private void loadHomeFragment() {
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(intent);
        finish(); // Optionally finish the LoginActivity to prevent going back
    }

}