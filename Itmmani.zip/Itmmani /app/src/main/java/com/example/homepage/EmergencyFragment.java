package com.example.homepage;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.gms.maps.SupportMapFragment;

import java.util.List;


public class EmergencyFragment extends Fragment {

    private Button buttonEmrg1;
    private Button buttonEmrg2;
    private Button buttonEmrg3;
    private Button buttonEmrg4;
    private Button buttonShare;


    public EmergencyFragment() {
        // Required empty public constructor
    }




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_emergency, container, false);



        buttonEmrg1 = view.findViewById(R.id.btnEmergency1);
        buttonEmrg2 = view.findViewById(R.id.btnEmergency2);
        buttonEmrg3 = view.findViewById(R.id.btnEmergency3);
        buttonEmrg4 = view.findViewById(R.id.btnEmergency4);
        buttonShare = view.findViewById(R.id.btnShareLocation);



        buttonEmrg1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Call the emergency number
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:" + 997));
                startActivity(intent);

            }
        });


        buttonEmrg2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Call the emergency number
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:" + 1919));
                startActivity(intent);

            }
        });


        buttonEmrg3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Call the emergency number
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:" + 999));
                startActivity(intent);

            }
        });



        buttonEmrg4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Call the emergency number
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:" + 112));
                startActivity(intent);

            }
        });


       /* private void getLocation(){
            PermissionListener permissionlistener = new PermissionListener() {
                @Override
                public void onPermissionGranted() {
                    Toast.makeText(getContext(), "Permission Granted", Toast.LENGTH_SHORT).show();
                }

                @Override
                public void onPermissionDenied(List<String> deniedPermissions) {
                    Toast.makeText(getContext(), "Permission Denied\n" + deniedPermissions.toString(), Toast.LENGTH_SHORT).show();
                }


            };

            TedPermission.create()
                    .setPermissionListener(permissionlistener)
                    .setDeniedMessage("If you reject permission,you can not use this service\n\nPlease turn on permissions at [Setting] > [Permission]")
                    .setPermissions(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION)
                    .check();
        }*/

        buttonShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(getContext(), "your location has been shared to get immediate assistance from licensed parties\n", Toast.LENGTH_SHORT).show();

            }
        });






        // Begin a transaction using getChildFragmentManager()
        FragmentTransaction transaction = getChildFragmentManager().beginTransaction();

        // Replace the FrameLayout container with a MapFragment
        SupportMapFragment mapFragment = SupportMapFragment.newInstance();
        transaction.replace(R.id.childFragmentContainer, mapFragment);

        // Commit the transaction
        transaction.commit();







      /*  // Begin a transaction
        FragmentTransaction transaction = getChildFragmentManager().beginTransaction();

        // Replace the FrameLayout container with a new fragment
        map_Fragment childFragment = new map_Fragment();
        transaction.replace(R.id.mapFrame, childFragment);

        // Commit the transaction
        transaction.commit();
*/


    /*    FrameLayout childFragmentContainer = view.findViewById(R.id.mapFrame);

        //ChildFragment childFragment = new ChildFragment();


        Fragment fragmentMap = new map_Fragment();
        //getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.mapFrame,fragmentMap).commit();
        getChildFragmentManager().beginTransaction().add(R.id.mapFrame, fragmentMap).commit();*/

        return view;



    }
}