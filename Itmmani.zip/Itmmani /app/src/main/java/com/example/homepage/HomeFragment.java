package com.example.homepage;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

public class HomeFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        View view = inflater.inflate(R.layout.fragment_home, container, false);

        // Reporting

        TextView textView1 = view.findViewById(R.id.textView4);
        textView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                navigateToReportFragment();
            }
        });


        // Resource

        TextView textView2 = view.findViewById(R.id.textView5);
        textView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                navigateToResourcesFragment();
            }
        });

        // Emergency

        TextView textView3 = view.findViewById(R.id.textView1);
        textView3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                navigateToEmergencyFragment();
            }
        });

        // Conselling

        TextView textView4 = view.findViewById(R.id.textView2);
        textView4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                navigateToConsellingFragment();
            }
        });

        // Security

        TextView textView5 = view.findViewById(R.id.textView3);
        textView5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                navigateToCSecurityFragment();
            }
        });

        return view;
    }





    //Reporting
    private void navigateToReportFragment() {

        ReportingFragment reportFragment = new ReportingFragment();

        FragmentTransaction transaction = requireActivity().getSupportFragmentManager().beginTransaction();

        transaction.replace(R.id.fragment_layout, reportFragment);

        transaction.addToBackStack(null);

        transaction.commit();
    }

    // Resource
    private void navigateToResourcesFragment() {

        ResourceFragment resourceFragment = new ResourceFragment();

        FragmentTransaction transaction = requireActivity().getSupportFragmentManager().beginTransaction();

        transaction.replace(R.id.fragment_layout, resourceFragment);

        transaction.addToBackStack(null);

        transaction.commit();
    }

    // Emergency
    private void navigateToEmergencyFragment() {

        EmergencyFragment emergencyFragment = new EmergencyFragment();

        FragmentTransaction transaction = requireActivity().getSupportFragmentManager().beginTransaction();

        transaction.replace(R.id.fragment_layout, emergencyFragment);

        transaction.addToBackStack(null);

        transaction.commit();
    }


    // Conselling
    private void navigateToConsellingFragment() {

        ConsellingFragment consellingFragment = new ConsellingFragment();

        FragmentTransaction transaction = requireActivity().getSupportFragmentManager().beginTransaction();

        transaction.replace(R.id.fragment_layout, consellingFragment);

        transaction.addToBackStack(null);

        transaction.commit();
    }

    // Security
    private void navigateToCSecurityFragment() {

        SecurityFragment securityFragment = new SecurityFragment();

        FragmentTransaction transaction = requireActivity().getSupportFragmentManager().beginTransaction();

        transaction.replace(R.id.fragment_layout, securityFragment);

        transaction.addToBackStack(null);

        transaction.commit();
    }
}
