package com.example.homepage;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ReportingFragment extends Fragment {


    private boolean isValidPhoneNumber;
    private String phoneNumber;
    private String regex;
    private EditText phoneTxt;
    private EditText addressTxt;
    private EditText descTxt;
    private Button submit;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_reporting, container, false);

        phoneTxt = view.findViewById(R.id.editTextPhone);
        addressTxt = view.findViewById(R.id.editTextTextMultiLine1);
        descTxt = view.findViewById(R.id.editTextTextMultiLine2);
        submit = view.findViewById(R.id.btnSubmit);


        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                phoneNumber = phoneTxt.getText().toString().trim();

                if (isValidPhoneNumber(phoneNumber)) {
                    Toast.makeText(getContext(), "Valid phone number", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getContext(), "Invalid phone number", Toast.LENGTH_SHORT).show();
                }






                if(TextUtils.isEmpty(phoneTxt.getText()) || TextUtils.isEmpty(addressTxt.getText())
                        || TextUtils.isEmpty(descTxt.getText()) || isValidPhoneNumber(phoneNumber) == false){

                    Toast.makeText(getContext(),"Please fill all the information",Toast.LENGTH_SHORT).show();
                } else {

                    Toast.makeText(getContext(),"Your report has been successfully submitted",Toast.LENGTH_SHORT).show();
                }

            }
        });



        return view;

    }

    private boolean isValidPhoneNumber(String num) {
        regex = "^(\\+\\d{1,4}[- ]?)?\\d{10}$";

        Pattern pattern = Pattern.compile(regex);

        Matcher matcher = pattern.matcher(num);

        return matcher.matches();
    }
}